import { targetIsNot } from '../../functions/eventHelper';

export default class Submenus {

  // Submenus class constructor
  constructor () {
     this.list = [];
     this.breakpoint = '960px';

     // Get the container element for the submenus
     this.container = document.querySelector( "#subMenus" );
  }

  // Implements the EventListener interface
  // See https://www.thecssninja.com/javascript/handleevent for more info
  handleEvent ( event ) {

    if ( event.type === 'click' ) {

      // Close the submenus if a click event falls outside of
      // the Active Sub Menus / Primary Link
      if (

        // Ignore clicks in/on Submenu or Primary Link
        targetIsNot( event.target, ['.submenus.active', '.primary-link', '.mobile-user-account-menu', '#toggleMobileAccountMenu'] )

        // and only ignore for Desktop View
        && window.matchMedia( '(min-width: 960px)' )
      )
      {
        this.close();
      }
    }
  }


 // Toggle opening or closing a specific submenu
 toggle ( which ) {
   const submenu = document.querySelector(".submenu[data-primary-link=" + which + "]");
   if (submenu.classList.contains("opened")) {
     this.close();
     this.bodyScrolling( "enable" );
   } else {
     this.open(submenu);
     this.bodyScrolling( "disable" );
   }
 }


 // Open Submenu
 // submenu = <div class='submenu'>
 open ( submenu ) {
   this.close();

   // open the targeted one
   submenu.classList.remove("closed");
   submenu.classList.add("opened");

   // change color of text and icons
   this.container.classList.add("active");
   document.addEventListener( 'click', this, true );

   if (!document.body.classList.contains('submenuActive')) {
     document.body.classList.add('submenuActive');
   }
 }


  // Close Submenu
  // submenu = <div class='submenu'>
 close () {

   // close any open submenus
   this.list.forEach( ( submenu ) => {
     if ( submenu.classList.contains("opened") ){
       submenu.classList.remove("opened");
       submenu.classList.add("closed");
     }
   } );

   // change color of text and icons
   this.container.classList.remove("active");

   if (document.body.classList.contains('submenuActive')) {
     document.body.classList.remove('submenuActive');
   }
 }

  bodyScrolling ( action ) {
    if ( window.matchMedia( '(max-width: ' + this.breakpoint + ')' ).matches ) {
      document.body.style.height = ( action === 'disable' ? '90vh' : 'unset' );
    }
  }
}