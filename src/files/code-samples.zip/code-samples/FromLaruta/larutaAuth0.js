import {validateEmailAddress} from '../functions/validateEmail';
import URLSearchParams from '@ungap/url-search-params';

export default class LarutaAuth0 {

  /**
   * constructor
   * @param clientID
   * @param domain
   * @param settings
   */
  constructor( clientID, domain, settings = {} ) {

    // Make sure we have a Client ID and Domain before continuing
    if (!clientID || !domain) console.error('No Client ID or Domain passed');

    /*
    * Set Properties
    ***********************/

    // clientID, domain, and settings are used to initialize Auth0Lock
    this.clientID = clientID;
    this.domain   = domain;
    this.settings = settings;

    // Holds user's typed input for the email field
    this.userEmailInput = null;

    // Container for the custom "No Laruta User" message
    this.larutaUserExistsElement = null;

    /** Overrides Auth0 Lock avatar method"
     * @link https://auth0.com/docs/libraries/lock/v11/configuration#avatar-object- */
    this.settings.avatar = this.overrideAvatar();

    // Allows tracking/resetting of the "No Laruta User" message in the Lock modal
    this.noLarutaUserMessageDisplayed = false;

    // Merge settings passed through constructor with ACF defined setting
    this.settings = Object.assign({}, this.settings, this.getSettingsFromFeatureOptions())

    // Initialize Auth0Lock
    /** @class Auth0LockPasswordless  */
    this.lock = new Auth0LockPasswordless(this.clientID, this.domain, this.settings);

    // Add LarutaAuth0 to the window object
    if (typeof window.LarutaAuth0 === 'undefined') window.LarutaAuth0 = this;

    // Methods to call on initialization:
    this.triggerModalFromCustomButtons();
    this.addEventListeners();
  }

  /**
   * triggerModalFromCustomButtons
   * Links with data-trigger="auth0Modal" will show the Login Modal
   */
  triggerModalFromCustomButtons() {
    document.addEventListener('click', event => {

      // check if the click target element has a [data-trigger=auth0Modal] attribute
      if (event.target.closest('[data-trigger=auth0Modal]')) {
        event.preventDefault();

        // trigger modal if the auth0 login modal button is on the page
        if (document.getElementById('a0LoginButton')) {

          // Now that we are using our own instance of Auth0LockPasswordLess,
          // we need to call the show() instead of forcing the auth0Button clicking.
          this.lock.show();
          this.reorderLockForm();
        }

        // fallback to normal login page if the auth0 button is not present
        else {
          window.location.href = event.target.getAttribute('href');
        }
      }
    });
  }

  /**
   * addEventListeners
   */
  addEventListeners() {
    let _this = this;

    /**
     * Auth0 event info can be found at:
     * @link https://auth0.com/docs/libraries/lock/v11/api
     */
    this.lock.on('socialOrEmail ready', function () {

      // Our customizations for the Lock modal is initialized here.
      _this.reorderLockForm();
      _this.createLoadingIndicator();
      _this.createLarutaUserExistsElement();
      _this.addEmailInputListeners();
      _this.addOverrideSubmitListener();
      _this.noLarutaUserMessageDisplayed = false;
    });

    this.lock.on('hide', function () {
      _this.removeOverrideSubmitListener();
      _this.noLarutaUserMessageDisplayed = false;
    });

    this.lock.on( 'vcode ready', function () {
      _this.resetSubmitButton();
      _this.resetLockForm();
      _this.noLarutaUserMessageDisplayed = false;
    } );
  }

  /**
   * createLarutaUserExistsElement
   * Builds the markup for the 'No Laruta User' message.
   * styles for .laruta-auth0-lock-user-check are in `_laruta-auth0-lock.scss` in parent theme sass assets
   */
  createLarutaUserExistsElement () {
    let message = "<div class='no-laruta-user-message'></div>";

    this.larutaUserExistsElement = document.createElement('div');
    this.larutaUserExistsElement.setAttribute('id', 'larutaAuth0LockUserCheck');
    this.larutaUserExistsElement.classList.add('laruta-auth0-lock-user-check');
    this.larutaUserExistsElement.innerHTML = message;

    let auth0LockContentElement = document.querySelector('.auth0-lock .auth0-lock-content .auth0-lock-input-email');
    if ( auth0LockContentElement && !auth0LockContentElement.contains( this.larutaUserExistsElement ) ) {
      auth0LockContentElement.appendChild(this.larutaUserExistsElement);
    }
  }

  /**
   * attachNewAccountMessage
   * Adds 'No Laruta User' message to the DOM
   */
  attachNewAccountMessage () {

    // Don't do anything if the email input field is empty or not a valid email address
    if ( !this.isUserInputValidEmailAddress() ) return;

    this.hideLoadingIndicator();
    this.collapseSocialLoginOptions();

    document.querySelector( '#larutaAuth0LockUserCheck .no-laruta-user-message' ).innerHTML = this.getNoLarutaUserFoundMessage();

    let larutaAuth0LockUserCheck = document.getElementById( 'larutaAuth0LockUserCheck' );
    larutaAuth0LockUserCheck.style.display = 'block';
    larutaAuth0LockUserCheck.style.opacity = '1';

    this.scrollToNoLarutaUserMessage();
  }

  /**
   * detachNewAccountMessage
   */
  detachNewAccountMessage () {
    let larutaAuth0LockUserCheck = document.getElementById( 'larutaAuth0LockUserCheck' );
    larutaAuth0LockUserCheck.style.opacity = '0';
    larutaAuth0LockUserCheck.style.display = 'none';
  }

  /**
   * addEmailInputListeners
   * Add keyup event listener to user email input field
   * and set the userEmailInput property
   */
  addEmailInputListeners() {
    let _this = this;

    const userEmailInputElement = document.querySelector('.auth0-lock input[type=text][id$=email]');

    userEmailInputElement.addEventListener('keyup', function (event) {
      _this.userEmailInput = event.target.value;
      _this.detachNewAccountMessage();

      if (_this.noLarutaUserMessageDisplayed) {
        _this.resetSubmitButton();
        _this.addOverrideSubmitListener();
        _this.noLarutaUserMessageDisplayed = false;
      }
    });

    userEmailInputElement.addEventListener('click', function (event) {
      // Remove a readonly attribute that gets added after clicking "submit"
      if (event.target.hasAttribute("readonly")) {
        event.target.removeAttribute("readonly");
      }
    });

  }

  /**
   * createLoadingIndicator
   * Builds the markup for the loading indicator displayed on submit
   * it is added to the DOM but set to `display: none` by default.
   * styles for .laruta-auth0-loading-indicator are in `_laruta-auth0-lock.scss` in parent theme sass assets
   */
  createLoadingIndicator () {
    const loadingIndicator = document.createElement('div');
    loadingIndicator.setAttribute('id', 'larutaAuth0LoadingIndicator');
    loadingIndicator.classList.add('laruta-auth0-loading-indicator');
    loadingIndicator.innerHTML = "<img src='/app/themes/laruta-themosis-parent/dist/images/loading-fountain.gif' style='margin-bottom: 10px; width: 33%;'>";

    let auth0LockContentElement = document.querySelector('.auth0-lock .auth0-lock-content .auth0-lock-input-email');
    if (auth0LockContentElement && !auth0LockContentElement.contains(loadingIndicator)) {
      auth0LockContentElement.appendChild(loadingIndicator);
    }
  }

  /**
   * showLoadingIndicator
   */
  showLoadingIndicator() {
    const loadingIndicator = document.getElementById( 'larutaAuth0LoadingIndicator' );
    loadingIndicator.style.display = 'flex';
  }

  /**
   * hideLoadingIndicator
   */
  hideLoadingIndicator() {
    const loadingIndicator = document.getElementById( 'larutaAuth0LoadingIndicator' );
    loadingIndicator.style.display = 'none';
  }

  /**
   * isUserInputValidEmailAddress
   * Simple Email Validation:
   * Checks if this.userEmailInput has a `@` and a `.`
   * @returns {boolean|*}
   */
  isUserInputValidEmailAddress () {
    return this.userEmailInput !== null && validateEmailAddress( this.userEmailInput );
  }

  /**
   * overrideAvatar
   * Using Fetch API, this checks if a LarutaUser exists for the passed email,
   * and retrieves a profile picture and name to be displayed.
   * This overrides Auth0's default avatar behavior which simply pulled an image from gravatar.
   * @link https://auth0.com/docs/libraries/lock/v11/configuration#avatar-object-
   * @returns {{displayName: displayName, url: url}}
   */
  overrideAvatar () {
    const _this = this;
    const avatarSettings = {

      // Get the Avatar Url
      url: function(email, cb) {

        // Prevent Fetching if there is no email valid
        if ( !validateEmailAddress( email ) ) return;

        let params = new URLSearchParams({ action: 'lrt_auth0_lock_does_user_exist', emailAddress: email });
        fetch( themosis.ajaxurl, { method: 'POST', body: params, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } } )
          .then( response => response.json() )
            .then( response => {
              let data = response.data;
              if ( data.userExists ) {
                cb( null, response.data.avatarUrl );
              }
            } )
              .catch( error => {
                console.error( 'There was a problem with fetch()', error )
              } )
      },


      // Get the Display Name
      // I know, this code is almost a repeat of the above,
      // but this is how Auth0 Lock does things.
      displayName: function(email, cb) {

        if ( !validateEmailAddress( email ) ) return;

        let params = new URLSearchParams({ action: 'lrt_auth0_lock_does_user_exist', emailAddress: email });
        fetch( themosis.ajaxurl, { method: 'POST', body: params, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } } )
          .then( response => response.json() )
            .then( response => {
              let data = response.data;
              if ( data.userExists === true ) {
                cb( null, response.data.displayName );
              }
            } )
              .catch( error => {
                console.error( 'There was a problem with fetch()', error )
              } )
      }
    }

    return avatarSettings;
  }

  /**
   * addOverrideSubmitListener
   */
  addOverrideSubmitListener () {
    document.querySelector( '.auth0-lock-submit' ).addEventListener( 'click', this );
  }

  /**
   * removeOverrideSubmitListener
   */
  removeOverrideSubmitListener () {
    document.querySelector( '.auth0-lock-submit' ).removeEventListener( 'click', this );
  }

  /**
   * handleEvent
   */
  handleEvent () {
    this.overrideSubmit ( event )
  }

  /**
   * overrideSubmit
   * Using Fetch API, we are doing the same LarutaUser check we did for the Avatar Override
   * to determine whether to display the 'No Laruta User' message
   * @param event
   */
  overrideSubmit ( event ) {

    // Cancel the default behavior, which would send the user to the confirmation code screen
    event.preventDefault();

    // If the 'No Laruta User' message is attached, remove it.
    this.detachNewAccountMessage();

    // Disable Typing any more characters in input
    this.disableTyping();

    // Show the loading indicator
    this.showLoadingIndicator();

    // Check for Laruta User
    let params = new URLSearchParams({ action: 'lrt_auth0_lock_does_user_exist', emailAddress: this.userEmailInput });
    fetch( themosis.ajaxurl, { method: 'POST', body: params, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } } )
      .then( response => response.json() )
        .then( response => {

          // Remove the submit button action override
          this.removeOverrideSubmitListener();

          // If a user is found, or a user was not found
          // but they already saw the 'No Laruta User' message,
          // then proceed to confirmation code screen
          /** @var userExists */
          if ( response.data.userExists || ( !response.data.userExists && this.noLarutaUserMessageDisplayed ) ) {
            document.querySelector( '.auth0-lock-submit' ).click();
          }

          // If a user is not found, display the 'No Laruta User' Message
          if ( !response.data.userExists ) {
            this.attachNewAccountMessage();
            this.updateSubmitButtonToConfirmButton();

            // Mark that the 'No Laruta User' message was shown
            this.noLarutaUserMessageDisplayed = true;
          }

        } )
          .catch( error => {
            console.error( 'There was a problem with fetch()', error )
          } )
  }

  /**
   * updateSubmitButtonToConfirmButton
   * Changes the text from Submit to Confirm if the 'No Laruta User' message is displayed
   */
  updateSubmitButtonToConfirmButton () {
    const submitButtonLabel     = document.querySelector( '.auth0-lock-submit > .auth0-label-submit' );
    this.submitButtonContent    = submitButtonLabel.innerHTML;
    submitButtonLabel.innerHTML = 'Create Account';

    const submitButton = document.querySelector( '.auth0-lock-submit');
    submitButton.classList.add('confirm-account');
  }

  /**
   * resetSubmitButton
   * Resets Confirm text back to Submit
   */
  resetSubmitButton () {
    const submitButtonLabel = document.querySelector( '.auth0-lock-submit > .auth0-label-submit' );
    submitButtonLabel.innerHTML = 'Submit';

    const submitButton = document.querySelector( '.auth0-lock-submit');
    submitButton.classList.remove('confirm-account');
  }

  /**
   * getNoLarutaUserFoundMessage
   * @returns {*}
   */
  getNoLarutaUserFoundMessage () {
    let message = themosis.features.LarutaAuth0.NoLarutaUserFoundMessage;
    if ( !message ) {
      console.error( 'Laruta Error: ACF Value is not defined at PrimaryCustomizations/Auth0/Auth0LockNoLarutaUserFoundMessage' );
      return '';
    }

    let replacement =
      this.userEmailInput
        ? "<span class='user-exists-email-address'>" + this.userEmailInput + "</span>"
        : 'the email you entered';

    return message.replace( '{{EMAIL_ADDRESS}}', replacement );
  }

  /**
   * collapseSocialLoginOptions
   * Switch to a more compact social login view if the 'No Laruta User' message is displayed
   */
  collapseSocialLoginOptions () {
    let socialButtons     = document.querySelectorAll( '.auth0-lock-social-button' );
    let socialButtonsPane = document.querySelector('.auth-lock-social-buttons-pane');
    let existingSignIn    = document.querySelector('.lrt-sign-in-via-message');

    if ( !socialButtonsPane ) return;
    if ( existingSignIn ) return;

    // swap classes for each social icon
    [].slice.call( socialButtons ).forEach( button => {
      if ( button.classList.contains( 'auth0-lock-social-big-button' ) ) {
        button.classList.remove('auth0-lock-social-big-button');
        button.classList.add('auth0-lock-social-small-button');
      }
    } );

    // Create and add a "Sign In Via" message above the new compact icons
    let signInViaMessage = document.createElement('p');
    signInViaMessage.innerHTML = 'Sign In Via';
    signInViaMessage.classList.add( 'lrt-sign-in-via-message' );
    socialButtonsPane.prepend( signInViaMessage );
  }

  /**
   * scrollToNoLarutaUserMessage()
   */
  scrollToNoLarutaUserMessage () {
    document.getElementById( 'larutaAuth0LockUserCheck' ).scrollIntoView( true );
  }

  /**
   * disableTyping()
   * @returns {boolean}
   *
   * There is no need for an 'enableTyping' because
   * the verification code is a different input, and
   * if you go back, the email input get reset
   */
  disableTyping() {
    const userEmailInput = document.querySelector('.auth0-lock input[type=text][id$=email]');
    if (userEmailInput.hasAttribute('readonly')) {
      return false;
    }

    userEmailInput.setAttribute('readonly', 'readonly');
    return true;
  }

  /**
   *
   */
  getSettingsFromFeatureOptions() {
    /**
     * For more info:
     * @link https://auth0.com/docs/libraries/lock/lock-ui-customization
     * @link https://github.com/auth0/lock/blob/master/src/i18n/en.js  */
    const emailAlternativeMessage = themosis.features.LarutaAuth0.EmailAlternativeMessage;

    return {
      languageDictionary: {
        title: this.getLockModalTitle(),
        passwordlessEmailAlternativeInstructions: this.getSignInOptionsMessage(),
        loginWithLabel: 'Login with %s',
        signUpWithLabel: 'Login with %s',
      },
    }
  }

  isRearrangingFieldsEnabled() {
    return themosis.features.LarutaAuth0.RearrangedFieldsEnabled;
  }

  getLockModalTitle() {
    return themosis.features.LarutaAuth0.LockModalTitle;
  }

  getSignInOptionsMessage() {
    return themosis.features.LarutaAuth0.EmailAlternativeMessage;
  }

  reorderLockForm() {
    if (this.isRearrangingFieldsEnabled()) {
      const lockForm = document.querySelector(".auth0-lock-form");
      lockForm.classList.add("lrt-auth0-lock-form-reordered");
    }
  }

  resetLockForm() {
    if (this.isRearrangingFieldsEnabled()) {
      const lockForm = document.querySelector(".auth0-lock-form");
      lockForm.classList.remove("lrt-auth0-lock-form-reordered");
    }
  }
}
