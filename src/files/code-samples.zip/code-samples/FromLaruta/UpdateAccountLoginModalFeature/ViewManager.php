<?php

namespace Theme\Features\UpdateAccountLoginModal;

use function lrt_get_laruta_user;
use function view;

class ViewManager
{
    private UpdateAccountLoginModalOption $updateAccountLoginModalOption;

    public function __construct(UpdateAccountLoginModalOption $updateAccountLoginModalOption)
    {
        $this->updateAccountLoginModalOption = $updateAccountLoginModalOption;

        $this->addActions();
        $this->sendQueryParamNameToFrontend();
    }

    public function addActions(): void
    {
        add_action('lrt_header_before', [$this, 'attachModalView']);
    }

    public function attachModalView(): void
    {
        if (isset($_REQUEST[$this->updateAccountLoginModalOption->getUpdateAccountQueryParamName()])) {
            $userHasValidName = UpdateAccountLoginModalFeature::getEnabledInstance()
                ->loginRedirectManager
                ->isUserFirstNameValid(
                    lrt_get_laruta_user()
                );

            if ($userHasValidName) {
                return;
            }

            $formId = $this->updateAccountLoginModalOption->getGravityFormId()->getACFValue();

            if ($formId) {
                echo view('features.updateAccountLoginModal.modal', ['formId' => $formId]);
            }
        }
    }

    public function sendQueryParamNameToFrontend(): void
    {
        add_filter('themosis_front_global', function ($jsVariables) {
            $userHasValidName = UpdateAccountLoginModalFeature::getEnabledInstance()
                ->loginRedirectManager
                ->isUserFirstNameValid(
                    lrt_get_laruta_user()
                );

            if ($userHasValidName) {
                return $jsVariables;
            }

            $jsVariables['features']['updateAccountRequest']['queryParamName'] = $this->updateAccountLoginModalOption->getUpdateAccountQueryParamName();

            return $jsVariables;
        });
    }
}