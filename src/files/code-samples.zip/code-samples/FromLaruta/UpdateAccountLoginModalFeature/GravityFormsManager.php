<?php

namespace Theme\Features\UpdateAccountLoginModal;

use Illuminate\Support\Str;
use Spatie\Url\Url;

class GravityFormsManager
{
    private UpdateAccountLoginModalOption $updateAccountLoginModalOption;

    public function __construct(UpdateAccountLoginModalOption $updateAccountLoginModalOption)
    {
        $this->updateAccountLoginModalOption = $updateAccountLoginModalOption;
        $this->addFilters();
    }

    public function addFilters(): void
    {
        add_filter('gform_user_registration_user_data_pre_populate', [$this, 'hideEmailAddressInMappedFields'], 10, 3);
        add_filter('gform_confirmation', [$this, 'attachRedirect'], 10, 4);
    }

    public function attachRedirect($confirmation, $form, $entryData, $ajax)
    {
        if((int) $this->updateAccountLoginModalOption->getGravityFormId()->getACFValue() !== (int) $form['id']) {
            return $confirmation;
        }

        return [
            'redirect' =>
                (string) Url::fromString($_SERVER['REQUEST_URI'])->withoutQueryParameter(
                    $this->updateAccountLoginModalOption->getUpdateAccountQueryParamName()
                )];
    }

    public function getGravityFormId(): int
    {
        return (int) (UpdateAccountLoginModalOption::build())->getGravityFormId();
    }

    public function hideEmailAddressInMappedFields($mapped_fields, $form, $feed)
    {
        if((int) $this->updateAccountLoginModalOption->getGravityFormId()->getACFValue() !== (int) $form['id']) {
            return $mapped_fields;
        }

        return collect($mapped_fields)
            ->map(static function($field){
                if(Str::contains($field, '@')){
                    $field = null;
                }

                return $field;
            })
            ->toArray();
    }
}