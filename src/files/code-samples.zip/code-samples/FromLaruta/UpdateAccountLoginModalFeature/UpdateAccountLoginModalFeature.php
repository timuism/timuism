<?php

namespace Theme\Features\UpdateAccountLoginModal;

use Theme\Facades\LRT_Logger;
use Theme\Features\FeatureBase;
use Theme\Models\Options\FeatureEnabledOption;
use Themosis\Support\Facades\Asset;
use Throwable;

class UpdateAccountLoginModalFeature extends FeatureBase
{
    public LoginRedirectManager $loginRedirectManager;
    public ViewManager $viewManager;
    public GravityFormsManager $gravityFormsManager;

    public function boot()
    {
        $this->loginRedirectManager = app(LoginRedirectManager::class);
        $this->viewManager = app(ViewManager::class);
        $this->gravityFormsManager = app(GravityFormsManager::class);

        $this->addAssets();
    }

    public static function isEnabled(): bool
    {
        return FeatureEnabledOption::build()->isUpdateAccountLoginModalEnabled();
    }

    public static function doDisabled()
    {
        return null;
    }

    public static function getBootHook(): ?string
    {
        return null;
    }

    public function addAssets(): void
    {
        try {
            Asset::add(
                'feature-update-account-login-modal',
                '/scripts/parent_feature_update_account_login_modal.js',
                ['jquery'],
                LRT_RELEASE_VERSION,
                true
            )->to(['front']);
        } catch (Throwable $throwable) {
            LRT_Logger::log('Error adding asset feature-update-account-login-modal ' . $throwable->getMessage());
        }
    }
}