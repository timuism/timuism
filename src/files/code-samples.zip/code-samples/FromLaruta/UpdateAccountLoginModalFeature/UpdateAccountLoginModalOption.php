<?php

namespace Theme\Features\UpdateAccountLoginModal;

use Theme\Models\Acf\LarutaACF;
use Theme\Models\Options\LarutaOption;

class UpdateAccountLoginModalOption extends LarutaOption
{
    public const UPDATE_ACCOUNT_LOGIN_MODAL_GRAVITY_FORM_ID = 'lrt_update_account_login_modal_gravity_form_id';

    public function getGravityFormId(bool $format = true, bool $load = true): LarutaACF
    {
        return $this->getLarutaACF(self::UPDATE_ACCOUNT_LOGIN_MODAL_GRAVITY_FORM_ID, $format, $load);
    }

    public function getUpdateAccountQueryParamName(): string
    {
        return 'update_account';
    }
}