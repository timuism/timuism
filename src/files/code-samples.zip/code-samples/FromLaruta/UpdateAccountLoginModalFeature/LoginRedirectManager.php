<?php

namespace Theme\Features\UpdateAccountLoginModal;

use Theme\Models\Users\LarutaUser;
use Theme\Models\Users\LarutaUserInterface;
use WP_User;
use function add_query_arg;

class LoginRedirectManager
{
    private UpdateAccountLoginModalOption $updateAccountLoginModalOption;

    public function __construct(UpdateAccountLoginModalOption $updateAccountLoginModalOption)
    {
        $this->updateAccountLoginModalOption = $updateAccountLoginModalOption;

        $this->addFilters();
    }

    private function addFilters(): void
    {
        add_filter('login_redirect', [$this, 'attachUpdateParam'], 20, 3);
    }

    public function isUserFirstNameValid(LarutaUserInterface $larutaUser): bool
    {
        return (bool)$larutaUser->getName(['firstName'], []);
    }

    public function getRedirectUrl(string $url, LarutaUserInterface $larutaUser): string
    {
        if (!$this->isUserFirstNameValid($larutaUser)) {
            return add_query_arg(
                $this->updateAccountLoginModalOption->getUpdateAccountQueryParamName(),
                true,
                $url
            );
        }

        return $url;
    }

    public function attachUpdateParam($redirect_to, $requested_redirect_to, $user)
    {
        if ($user instanceof WP_User) {
            if (!$redirect_to) {
                $redirect_to = '/';
            }

            return $this->getRedirectUrl($redirect_to, new LarutaUser($user));
        }

        return $redirect_to;
    }
}
