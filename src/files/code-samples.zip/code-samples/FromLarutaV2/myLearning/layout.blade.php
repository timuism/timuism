<x-layout title="" feature="my-learning" customLayout="true" hideFooter="true">
    <main
        class="flex-grow flex"
        x-data="{
            setHeight($refs){
                const maxHeight =
                    window.innerHeight > 800 // we are only setting a max-height if the window is greater than 800px
                    ? ( window.innerHeight - document.getElementById('site-menus').offsetHeight) + 'px'
                    : 'unset';

                [$refs.menu, $refs.section].forEach((elem) => {
                    elem.style.maxHeight = maxHeight;
                });
            },
        }"
        x-init="setHeight($refs)"
        @resize.window.debounce="setHeight($refs)"
    >

        <div class="bg-primary-1 grid grid-cols-12 w-full">

            <aside class="md:hidden">
                @include('front.account.mobileMenu', [
                    'links' => [
                        ['href'=> '/my-learning/upcoming', 'text' => 'Upcoming CPE & Events', 'icon' => 'upcoming-cpe-and-events'],
                        ['href'=> '/my-learning/on-demand', 'text' => 'My On-Demand', 'icon' => 'on-demand'],
                        ['href'=> '/my-learning/history', 'text' => 'CPE History & Transcript', 'icon' => 'Transcript'],
                    ],
                ])
            </aside>

            <aside x-ref="menu" class="bg-primary-2 hidden md:grid md:col-span-3">
                <div class="overflow-y-scroll" x-ref="content">
                    @include('front.account.menu')
                </div>
            </aside>


            <section x-ref="section" class="col-span-12 md:col-span-9 flex flex-col justify-between md:px-4">
                <div x-ref="content" class="overflow-y-scroll">
                    @yield('content')
                </div>

                <footer class="justify-self-end flex justify-between items-center border-t-4 border-primary-2 text-gray-3 mx-4 py-4 px-4 max-w-screen-xl">
                    {{-- using @stack because the pagination is rendered with laravel pagination + livewire and sits within the above @section('content') --}}
                    @stack('pagination')
                </footer>
            </section>
        </div>
    </main>
</x-layout>
