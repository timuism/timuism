@php
    // determine icon placement (before or after text)
    $reverse = isset($reverse) && $reverse ? 'flex-row-reverse' : '';

    // define disabled button styles
    $disabled = $disabled ?? false;
    $disabled_classes = $disabled ? "pointer-events-none opacity-50" : '';

    // add loading output @todo: create custom loading state
    $loading = $loading ?? false;
    $loadingContent = $loadingContent ?? '<span class="w-full absolute icon-loading"></span>';

    // set size of the icon based on the size passed by parent button
    $size = $size ?? 'large';
    $icon_size = match($size) {
        'compact' => 'text-12',
        'sm', 'small' => "text-14",
        default => "text-16",
    };
@endphp

<button
    {{
        $attributes->merge([
            'class' => "sail-button {$reverse} {$disabled_classes} inline-flex leading-none items-center justify-center transition duration-300",
        ])
    }}
>
    @isset($icon)
        <x-icon class="
            {{$icon_size}}
            {{$loading ? 'opacity-0' : ''}}
            {{$reverse ? 'ml-2' : ''}}
            inline-block
        ">
            {{$icon}}
        </x-icon>
    @endisset

    @isset($slot)
        <span class="{{$loading ? 'opacity-0' : ''}} inline-block">
            {!! $slot !!}
        </span>
    @endisset

    @if($loading)
        {{-- default defined at top of this file: <span class="w-full absolute icon-loading"></span> --}}
        {!! $loadingContent !!}
    @endif

</button>
