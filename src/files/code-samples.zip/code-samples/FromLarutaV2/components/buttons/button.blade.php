<?php
$type = $type ?? 'solid';
$color = $color ?? 'primary';
$icon = $icon ?? null;

$type_classes = match($type) {
    'stroke' => "
            text-{$color}-2 bg-white
            hover:bg-{$color}-1 hover:text-gray-4 shadow-sm
            border border-gray-3",
    default => "
            text-white bg-{$color}-2 hover:bg-{$color}-3 focus:ring-{$color}-2",
};

$shared_classes = 'text-16 px-4 py-3 font-normal rounded-lg leading-1 tracking-wide font-semibold space-x-2';
?>

<x-abstract-button
    {{
        $attributes->merge([
            'class' => implode(' ', [
                $type_classes,
                $shared_classes,
            ]),
        ])
    }}
>
    {!! $slot !!}
</x-abstract-button>
