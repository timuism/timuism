<?php
    $type = $type ?? 'solid';
    $size = $size ?? 'large';
    $color = $color ?? 'success';
    $icon = $icon ?? null;

    $size_classes = match($size) {
        'sm', 'small' => "text-14 px-4 py-2",
        default => $icon ? "text-16 uppercase px-8 py-4" : "text-16 uppercase px-10 py-4",
    };

    $type_classes = match($type) {
        'stroke' => "
            text-{$color}-2 hover:bg-{$color}-3 bg-white
            border-2 border-{$color}-2 hover:border-{$color}-2",
        default => "
            text-white bg-{$color}-2 hover:bg-{$color}-3 focus:ring-{$color}-2",
    };

    $shared_classes = 'rounded-lg shadow leading-1 tracking-wide font-semibold space-x-2';
?>

<x-abstract-button
    {{
        $attributes->merge([
            'class' => implode(' ', [
                $size_classes,
                $type_classes,
                $shared_classes,
            ]),
        ])
    }}
>
    {!! $slot !!}
</x-abstract-button>
