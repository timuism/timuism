@php
    $color = $color ?? 'primary';
    $size = $size ?? 'small';
    $icon = $icon ?? Icon::externalLink();

    $size_classes = match($size) {
        'lg', 'large' => "markup-a text-{$color}-2 hover:text-{$color}-3",
        default => " text-11 font-medium hover:font-bold uppercase text-{$color}-2 hover:text-{$color}-3",
    };

    $shared_classes = "inline-flex items-center justify-center space-x-1 cursor-pointer";
@endphp

<a
    {{
        $attributes->merge([
            'class' => implode(' ', [$shared_classes, $size_classes]),
        ])
    }}
>

    <x-icon class="inline-block text-12">
        {!! $icon !!}
    </x-icon>

    <div class="tracking-wide underline">
        {!! $slot !!}
    </div>

</a>
