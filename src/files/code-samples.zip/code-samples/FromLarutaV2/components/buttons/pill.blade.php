@php
    $type = $type ?? 'solid';
    $size = $size ?? 'large';
    $color = $color ?? 'primary';

    $size_classes = match($size) {
        'sm', 'small' => "text-12 text-14 px-8 py-3",
        'md', 'medium' => "text-16 px-10 py-4",
        default => "text-16 px-14 py-6",
    };

    $type_classes = match($type) {
        'stroke' => "
            text-{$color}-2 hover:text-{$color}-3 bg-white
            border-2 border-{$color}-2 hover:border-{$color}-3
            focus:ring-${color}-1",
        'ghost' => "
            text-{$color}-2 hover:text-{$color}-3 bg-white
            border-2 border-gray-1
             focus:ring-gray-1",
        'text' => "
            text-{$color}-2 hover:text-{$color}-3
            bg-opacity-0 border-0 hover:bg-opacity-1
            focus:ring-gray-1",
        default => "
            text-white bg-{$color}-2 hover:bg-{$color}-3 shadow
            focus:ring-${color}-3",
    };

    $shared_classes = "focus:outline-none focus:border-transparent focus:ring-4 rounded-full leading-none tracking-tight font-semibold space-x-1";
@endphp

<x-abstract-button
    {{
        $attributes->merge([
            'class' => implode(' ', [
                $type_classes,
                $size_classes,
                $shared_classes,
            ]),

            // text button overrides the default loading icon (defined in <x-button>)
            'loadingContent' => ($type == 'text' ? 'Loading…' : null),
        ])
    }}
>
        {!! $slot !!}
</x-abstract-button>
