@php
$color = $color ?? 'primary';
$icon = $icon ?? null;

$classes = "text-14 text-{$color}-2 hover:text-{$color}-3 font-semibold rounded-md
    bg-transparent focus:outline-none focus:border-transparent focus:bg-primary-1 space-x-2 p-2"
@endphp

<x-abstract-button
    {{
        $attributes->merge([
            'class' => $classes,
            'size' => 'compact', // manually passing a custom size, used to set a smaller icon size
            'reverse' => true,
        ])
    }}
>
    {!! $slot !!}
</x-abstract-button>
